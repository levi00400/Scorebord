Scorebord Android-project

Dit project verpakt de meegeleverde scorebord HTML als een Android-app.
De app opent liggend en fullscreen, en de bestaande scorebordfuncties blijven in de HTML.

Bouwen met Android Studio:
1. Open deze map als project.
2. Laat Gradle de Android Gradle Plugin downloaden.
3. Build > Build APK(s).
4. De APK staat daarna onder app/build/outputs/apk/debug/.
